export interface Client {
    entityId: number,
    entityLabel: string;
    email: string;
    telephone: string;
}
