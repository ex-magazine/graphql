export const environment = {
  production: true,
  contenta_url: 'http://contenta.local',
  graphql: '/graphql',
};
