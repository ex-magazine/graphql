import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timesheet-record',
  templateUrl: './timesheet-record.component.html',
  styleUrls: ['./timesheet-record.component.css']
})
export class TimesheetRecordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
