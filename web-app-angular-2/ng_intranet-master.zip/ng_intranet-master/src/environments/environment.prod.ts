export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyD6RQWUtge9kdEJ8uhOgf12kjrt1Oq7Uy8",
    authDomain: "fls-intranet.firebaseapp.com",
    databaseURL: "https://fls-intranet.firebaseio.com",
    projectId: "fls-intranet",
    storageBucket: "fls-intranet.appspot.com",
    messagingSenderId: "97494651751"
  }
};
